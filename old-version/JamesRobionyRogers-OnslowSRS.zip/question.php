<!-- Connecting to the Database -->
<?php 

	include 'includes/dbc.php';

	include 'includes/question-backend.php';

	// echo "Score: $score  -  Question: $questionNum";
	echo "userAnswer: " . $_POST['userAnswer']; 

	
?>

<!-- Start of HTML Page -->

<!DOCTYPE html>
<html lang="en">

    <!-- Constants.php should incude: Site title & other constants -->
	<?php include 'includes/constants.php'; ?>

	<head>
		<title><?php echo $title ?></title>
		<?php include 'includes/head.php'; ?>
	</head>

	<body>
		<div id="body-wrapper">

			<?php include 'includes/header.php'; ?>

	      	<div class="title-page">
	         	<div id="title-container">
				 <!-- TODO: Name of the lesson -->
	            	<h1 class="lesson-title"><?php echo $lessonName; ?></h1>
	        </div>

	        <div class="question-container">

				<?php 
					// $questions = getQuestions($quizID); 
					// // var_dump($questions);
					// $currentQuestion = $questions[0];

					// echo $currentQuestionID['questionID'];  // use the [] bc its an assoc-array

				?>

	        	<p class="question-text"><?php echo $currentQuestion; ?></p>
	         </div>
	      </div>

			<?php 
				// query to check the question type		
				$qT = checkQuestionType($currentQuestion); 
				// echo "Question Type: " . $qT['questionType'];
				

				if ($qT['questionType'] == 'multi') {		// query or $randomQuestionType
					include 'includes/multi-choice.php';
				}

				else if ($qT['questionType'] == 'text') {  // query or $randomQuestionType
					include 'includes/text-box.php';
				}

				else {
					$randQuestionType = mt_rand(1, 2);

					if ($randQuestionType == 1) {include 'includes/multi-choice.php';}
					else {include 'includes/text-box.php';}
				}

				var_dump($questions);
				var_dump($questionNum);
			?>

			<div class="progress-wrapper">
				<div class="progress">
					<div class="progress-done" data-done="0"></div>
				</div>
				<!-- TODO: php for question number as a percent -->
				<p class="progress-text"></p> 

				<form name="question" id="next-question-form" action="question.php?id=<?php echo $quizID ?>" onsubmit="return validateForm()" method="post">
					<input class="user-answer hidden" name="userAnswer" value="">
					<input class="next-question hidden" name="questionNum" value="<?php echo $questionNum; ?>">

					<input id="next-question" type="submit" name="asked" value="Next Question">
				</form>

			</div>
		</div>

		<div class="js-info">
			<div class="questions-length"><?php echo count($questions); ?></div>
			<div class="question-num"><?php echo $questionNum; ?></div>

		</div>

		<?php include 'includes/scripts.php'; ?>
		<script type="text/javascript" src="js/progress-bar.js"></script>

	</body>
</html>