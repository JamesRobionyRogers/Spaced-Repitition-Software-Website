-- Setting up the db tables 

CREATE TABLE IF NOT EXISTS subjects(
    subjectID INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subjectName TINYTEXT NOT NULL,
    subjectImg VARCHAR(1025)
);

CREATE TABLE IF NOT EXISTS questions(
    questionID SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    subjectID INT UNSIGNED,
    FOREIGN KEY (subjectID) REFERENCES subjects(subjectID),
    questionText VARCHAR(1024) NOT NULL,
    media VARCHAR(1024), -- USED FOR URLS TO IMGS, GIFS, ETC... 
    questionType ENUM("both", "text", "multi") NOT NULL

    -- Question Types:
    --   0 = BOTH Question Types
    --   1 = Text box ONLY
    --   2 = Multi-choise ONLY
);

CREATE TABLE IF NOT EXISTS correctAnswers(
    correctAnswerID SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    questionID SMALLINT UNSIGNED,
    FOREIGN KEY (questionID) REFERENCES questions(questionID),
    correctAnswer VARCHAR(255) NOT NULL, 
    priorityAnswer BOOLEAN NOT NULL
);

CREATE TABLE IF NOT EXISTS incorrectAnswers(
    incorrectAnswerID SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    questionID SMALLINT UNSIGNED,
    FOREIGN KEY (questionID) REFERENCES questions(questionID),
    incorrectAnswer VARCHAR(255) NOT NULL
);



-- Inseting data into tables 

-- Adding Subjects Data
INSERT INTO subjects(subjectID, subjectName, subjectImg)
    -- use NULL for the AUTO_INCREMENT column
    VALUES  (NULL, "Ngati Toa", "./imgs/undraw_ngati-toa.svg"),    
            (NULL, "Onslow College", "./imgs/undraw_onslow-college.svg"),    
            (NULL, "Johnsonville", "./imgs/undraw_johnsonville.svg"), 
            (NULL, "Wellington", "./imgs/undraw_wellington.svg"), 
            (NULL, "School Values", "./imgs/undraw_school-values.svg");

-- Adding Question Data
INSERT INTO questions(questionID, subjectID, questionText, media, questionType)
    -- use NULL for the AUTO_INCREMENT column
    VALUES  
        -- Ngati Toa Questions 1 - 15
        (NULL, 1, "What is the full name of the Ngāti Toa iwi?", NULL, "both"), 
        (NULL, 1, "What does ‘rangatira’ stand for?", NULL, "both"), 
        (NULL, 1, "When was Te Rauparaha born?", NULL, "multi"), 
        (NULL, 1, "Te Rauparaha is the author of which famous Māori haka, popularly known for being performed by the All Blacks?", NULL, "text"),
        (NULL, 1, "What does the ‘mate’, from the Ngāti Toa haka penned by Te Rauparaha, stand for?", NULL, "both"),
        (NULL, 1, "How many marae does Ngāti Toa have?", NULL, "both"),
        (NULL, 1, "How many marae does Ngāti Toa have on the North Island?", NULL, "both"),
        (NULL, 1, "Ngāti Toa emigrated southward from which region?", NULL, "both"),
        (NULL, 1, "Ngāti Toa are descendents of Hoturua, captain of which waka (canoe)?", NULL, "both"),
        (NULL, 1, "The people of Ngāti Toa who did not migrate south became which tribe?", NULL, "both"),
        (NULL, 1, "What does 'rohe pōtae' (in all lower case) mean in English?", NULL, "both"),
        (NULL, 1, "Alongside the Te Āti Awa iwi, Ngāti Toa operates which radio station inthe Wellington region?", NULL, "multi"),
        (NULL, 1, "Tupahau led around 300 warriors against Tamure's army of…", NULL, "both"),
        (NULL, 1, "Today, Ngāti Toa operates health services under the name…", NULL, "both"),
        (NULL, 1, "Who headed Ngāti Toa's migration southward?", NULL, "both"),
        
        -- Onslow College Questions 16 - 30
        (NULL, 2, "In what year did Onslow College open?", NULL, "multi"), 
        (NULL, 2, "In what decade did Onslow College abolish the school uniform following a student rebellion?", NULL, "multi"),
        (NULL, 2, "In the school’s motto ‘Levavi oculos meos in montes’/‘Ka anga atuaku kanohi ki nga maunga’, what does ‘oculus’/‘kanohi’ mean in English?", NULL, "both"),
        (NULL, 2, "The school has two versions of its motto ‘Lift your eyes to the hills’. One is in Māori, one is in … what other language?", NULL, "both"),
        (NULL, 2, "In 2021, Onslow College adopted five new values: whenua, whakapapa, diversity, community … name the missing value:", NULL, "both"),
        (NULL, 2, "What is the Māori name for Onslow College?", NULL, "both"),
        (NULL, 2, "For whom is Onslow College named?", NULL, "both"),
        (NULL, 2, "Onslow College sits beneath what mountain, currently named Mount Kaukau?", NULL, "both"),
        (NULL, 2, "When was the building now called Te Ara a Maui completed?", NULL, "both"),
        (NULL, 2, "When did Onslow College implement the new school values?", NULL, "both"),
        (NULL, 2, "What is 'kākā' in English?", NULL, "both"),
        (NULL, 2, "Who is the current principal?", NULL, "both"),
        (NULL, 2, "Building of the new buildings is expected to take at least…", NULL, "both"),
        (NULL, 2, "In which suburb is Onslow College located?", NULL, "both"),
        (NULL, 2, "The school motto is taken from a verse from…", NULL, "both"),

        -- Johnsonville Questions 31 - 45
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        (NULL, 3, "", NULL, ""),
        -- Wellington Questions 46 - 60
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        (NULL, 4, "", NULL, ""),
        -- School Values Questions 60 - 75
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, ""),
        (NULL, 5, "", NULL, "");



-- Adding Correct Answers 
INSERT INTO correctAnswers(correctAnswerID, questionID, correctAnswer, priorityAnswer)
    -- use NULL for the AUTO_INCREMENT column
    VALUES  
        -- Ngati Toa Answers 
        (NULL, 1, "Ngāti Toa Rangatira",    TRUE), (NULL, 1, "Ngati Toa Rangatira", FALSE), (NULL, 1, "Ngāti Toarangatira", FALSE), (NULL, 1, "Ngati Toarangatira", FALSE),
        (NULL, 2, "champion",               TRUE), 
        (NULL, 3, "1760s",                  TRUE), 
        (NULL, 4, "ka mate",                TRUE), 
        (NULL, 5, "Death",                  TRUE), (NULL, 5, "die", FALSE), (NULL, 5, "to die", FALSE),
        (NULL, 6, "4",                      TRUE),
        (NULL, 7, "2",                      TRUE), 
        (NULL, 8, "Waikato",                TRUE), (NULL, 8, "Kawhia", FALSE), (NULL, 8, "Kāwhia", FALSE),
        (NULL, 10, "Ngāti Mahuta",          TRUE), (NULL, 10, "Ngati Mahuta", FALSE),  
        (NULL, 11, "Tribal boundaries",     TRUE),  
        (NULL, 12, "Atiawa Toa FM",         TRUE),  
        (NULL, 13, "2000",                  TRUE), (NULL, 13, "2,000", FALSE),  (NULL, 13, "2 000", FALSE),  
        (NULL, 14, "Ora Toa",               TRUE),  
        (NULL, 15, "Te Rauparaha",          TRUE), 

        -- Onslow College Answers
        (NULL, 16, "1956", TRUE),  
        (NULL, 17, "1970s", TRUE),  
        (NULL, 18, "Eye", TRUE),  
        (NULL, 19, "Latin", TRUE),  
        (NULL, 20, "Whānau", TRUE), (NULL, 20, "whanau", FALSE),  

        (NULL, 21, "Te Kāreti o Onslow", TRUE),  
        (NULL, 22, "The governor of New Zealand", TRUE), 

        (NULL, 23, "Tarikākā", TRUE), (NULL, 23, "Tarikaka", FALSE),  
        (NULL, 24, "2013", TRUE),  
        (NULL, 25, "2021", TRUE),
        (NULL, 26, "Parrot", TRUE), (NULL, 26, "Parrots", FALSE),
        (NULL, 27, "Sheena Millar", TRUE), (NULL, 27, "Miss Millar", FALSE), (NULL, 27, "Ms Millar", FALSE), (NULL, 27, "Mrs Millar", FALSE),
        (NULL, 28, "5 years", TRUE),
        (NULL, 29, "Johnsonville", TRUE),
        (NULL, 30, "The Bible", TRUE), (NULL, 30, "Bible", FALSE);

        -- (NULL, , "", TRUE/FALSE),  


-- Adding Incorrect Answers (For Multi-choice)
INSERT INTO incorrectAnswers(incorrectAnswerID, questionID, incorrectAnswer)
    -- use NULL for the AUTO_INCREMENT column
    VALUES  
        -- Ngati Toa Incorrect Answers  
        (NULL, 1, "Ngā Toa Rangatahi"), (NULL, 1, "Ngāti Toa Ruatahi"), (NULL, 1, "Ngāti Toa Ruatira"), 
        (NULL, 2, "warrior"), (NULL, 2, "honest"), (NULL, 2, "brave"), 
        (NULL, 3, "1820s"), (NULL, 3, "1880s"), (NULL, 3, "1940s"),
        (NULL, 5, "Life"), (NULL, 5, "Ball"), (NULL, 5, "War"),
        (NULL, 6, "1"), (NULL, 6, "2"), (NULL, 6, "3"),
        (NULL, 7, "1"), (NULL, 7, "3"), (NULL, 7, "4"),
        (NULL, 8, "Auckland"), (NULL, 8, "Central Plateau"), (NULL, 8, "Manuwatu"), 
        (NULL, 9, "Tokomaru"), (NULL, 9, "Te Arawa"), (NULL, 9, "Tākitimu"), 
        (NULL, 10, "Ngāti Maniapoto"), (NULL, 10, "Ngāti Ira"), (NULL, 10, "Ngāti Tara"), 
        (NULL, 11, "Basket"), (NULL, 11, "Tribal traditions"), (NULL, 11, "Electorate"), 
        (NULL, 12, "Awa FM"), (NULL, 12, "Te Arawa FM"), (NULL, 12, "Radio Tainui"), 
        (NULL, 13, "600"), (NULL, 13, "1200"), (NULL, 13, "2500"), 
        (NULL, 14, "Toa Ora"), (NULL, 14, "Hauroa Toa"), (NULL, 14, "Toa Hauora"), 
        (NULL, 15, "Tupahau"), (NULL, 15, "Tamure"), (NULL, 15, "Toarangatira"),

        -- Onslow College Incorrect Answers
        (NULL, 16, "1962"),(NULL, 16, "1973"),(NULL, 16, "1990"),
        (NULL, 17, "1960s"),(NULL, 17, "1980s"),(NULL, 17, "1990s"),
        (NULL, 18, "Lift"),(NULL, 18, "Mountain"),(NULL, 18, "School"),
        (NULL, 19, "French"),(NULL, 19, "Chinese"),(NULL, 19, "Greek"),
        (NULL, 20, "Iwi"),(NULL, 20, "Hapu"),(NULL, 20, "Tangata"),
        (NULL, 21, "Te Kura Tuarua o Onslow"),(NULL, 21, "Te Kura Kaupapa o Onslow"),(NULL, 21, "Te Kura o Onslow"),
        (NULL, 22, "The college's first school principal"),(NULL, 22, "Prime Minister of New Zealand"),(NULL, 22, "The mayor of Johnsonville"),
        (NULL, 23, "Tarikea"),(NULL, 23, "Taripukeko"),(NULL, 23, "Tarikakapo"),
        (NULL, 24, "2014"),(NULL, 24, "2015"),(NULL, 24, "2016"),
        (NULL, 25, "2020"),(NULL, 25, "2019"),(NULL, 25, "2018"),
        (NULL, 26, "Bird"),(NULL, 26, "Finch"),(NULL, 26, "Fantail"),
        (NULL, 27, "Penny Kinsella"),(NULL, 27, "Warren Henderson"),(NULL, 27, "Janet Glenn"),
        (NULL, 28, "6 months"),(NULL, 28, "1 year"),(NULL, 28, "3 years"),
        (NULL, 29, "Khandallah"),(NULL, 29, "Ngaio"),(NULL, 29, "Crofton Downs"),
        (NULL, 30, "A famous poem"),(NULL, 30, "The Treaty of Waitangi"),(NULL, 30, "A science textbook"),

        -- Johnsonville Incorrect Answers
        (NULL, 31, ""), (NULL, 31, ""), (NULL, 31, ""),  
        (NULL, 32, ""), (NULL, 32, ""), (NULL, 32, ""),  
        (NULL, 33, ""), (NULL, 33, ""), (NULL, 33, ""),  
        (NULL, 34, ""), (NULL, 34, ""), (NULL, 34, ""),  
        (NULL, 35, ""), (NULL, 35, ""), (NULL, 35, ""),  
        (NULL, 36, ""), (NULL, 36, ""), (NULL, 36, ""),  
        (NULL, 37, ""), (NULL, 37, ""), (NULL, 37, ""),  
        (NULL, 38, ""), (NULL, 38, ""), (NULL, 38, ""),  
        (NULL, 39, ""), (NULL, 39, ""), (NULL, 39, ""),  
        (NULL, 30, ""), (NULL, 30, ""), (NULL, 30, ""),  
        (NULL, 41, ""), (NULL, 41, ""), (NULL, 41, ""),  
        (NULL, 42, ""), (NULL, 42, ""), (NULL, 42, ""),  
        (NULL, 44, ""), (NULL, 44, ""), (NULL, 44, ""),  
        (NULL, 44, ""), (NULL, 44, ""), (NULL, 44, ""),  
        (NULL, 45, ""), (NULL, 45, ""), (NULL, 45, ""),  

        -- Wellington Incorrect Answers
        (NULL, 46, ""), (NULL, 46, ""), (NULL, 46, ""),  
        (NULL, 47, ""), (NULL, 47, ""), (NULL, 47, ""),  
        (NULL, 48, ""), (NULL, 48, ""), (NULL, 48, ""),  
        (NULL, 49, ""), (NULL, 49, ""), (NULL, 49, ""),  
        (NULL, 50, ""), (NULL, 50, ""), (NULL, 50, ""),  
        (NULL, 51, ""), (NULL, 51, ""), (NULL, 51, ""),  
        (NULL, 52, ""), (NULL, 52, ""), (NULL, 52, ""),  
        (NULL, 53, ""), (NULL, 53, ""), (NULL, 53, ""),  
        (NULL, 54, ""), (NULL, 54, ""), (NULL, 54, ""),  
        (NULL, 55, ""), (NULL, 55, ""), (NULL, 55, ""),  
        (NULL, 56, ""), (NULL, 56, ""), (NULL, 56, ""),  
        (NULL, 57, ""), (NULL, 57, ""), (NULL, 57, ""),  
        (NULL, 58, ""), (NULL, 58, ""), (NULL, 58, ""),  
        (NULL, 59, ""), (NULL, 59, ""), (NULL, 59, ""),  
        (NULL, 60, ""), (NULL, 60, ""), (NULL, 60, ""),

        -- School Values Incorrect Answers
        (NULL, 61, ""), (NULL, 61, ""), (NULL, 61, ""),  
        (NULL, 62, ""), (NULL, 62, ""), (NULL, 62, ""),  
        (NULL, 63, ""), (NULL, 63, ""), (NULL, 63, ""),  
        (NULL, 64, ""), (NULL, 64, ""), (NULL, 64, ""),  
        (NULL, 65, ""), (NULL, 65, ""), (NULL, 65, ""), 
        (NULL, 66, ""), (NULL, 66, ""), (NULL, 66, ""), 
        (NULL, 67, ""), (NULL, 67, ""), (NULL, 67, ""),
        (NULL, 68, ""), (NULL, 68, ""), (NULL, 68, ""),
        (NULL, 69, ""), (NULL, 69, ""), (NULL, 69, ""),
        (NULL, 70, ""), (NULL, 70, ""), (NULL, 70, ""),
        (NULL, 71, ""), (NULL, 71, ""), (NULL, 71, ""),
        (NULL, 72, ""), (NULL, 72, ""), (NULL, 72, ""),
        (NULL, 73, ""), (NULL, 73, ""), (NULL, 73, ""),
        (NULL, 74, ""), (NULL, 74, ""), (NULL, 74, ""),
        (NULL, 75, ""), (NULL, 75, ""), (NULL, 75, "");


        -- Onslow College Answers 


-- Procedures in SQL

-- Retrieve all subjects from the database
DELIMITER $$
CREATE DEFINER=`root`@`localhost` 
PROCEDURE `GetSubjects`()
    SELECT  subjectID, subjectName, subjectImg
    FROM    subjects$$
DELIMITER ;

-- Retrieve the lesson Subject using lesson id
DELIMITER $$
CREATE DEFINER=`root`@`localhost` 
PROCEDURE `GetSubjectName`(IN `@SubjectID` INT UNSIGNED)
SELECT  subjectName

    FROM    subjects
    WHERE   subjectID = `@SubjectID`$$

DELIMITER ;



-- Retrieve 10 questionsIDs from a subject passed through param
DELIMITER $$
CREATE DEFINER=`root`@`localhost` 
PROCEDURE `GetTenQuestions`(IN `@SubjectID` INT UNSIGNED)

    SELECT  questionID, subjectID, questionText
    FROM    questions
    WHERE   subjectID = `@SubjectID`
    ORDER BY RAND()
    LIMIT 5$$

DELIMITER ;

-- Retrieve a questions questionID 
DELIMITER $$
CREATE DEFINER=`root`@`localhost` 
PROCEDURE `GetQuestionID`(IN `@QuestionText` VARCHAR(1024))

    SELECT  questionID
    FROM    questions
    WHERE   questionText = `@QuestionText`$$

DELIMITER ;

-- Retrieve the questions type 
DELIMITER $$
CREATE DEFINER=`root`@`localhost` 
PROCEDURE `CheckQuestionType` (IN `@Question` VARCHAR(1024))
    
    SELECT questionType
    FROM questions
    WHERE questionText = `@Question`$$

DELIMITER ;

-- Retrieve the correct answer for a question
DELIMITER $$
CREATE DEFINER=`root`@`localhost` 
PROCEDURE `GetCorrectAnswers`(IN `@QuestionID` INT UNSIGNED)

    SELECT *
    FROM correctanswers
    WHERE correctanswers.questionID = `@QuestionID`
    AND correctanswers.priorityAnswer = 1
    OR correctanswers.priorityAnswer = 0
    ORDER BY (CASE WHEN correctanswers.priorityAnswer = 1 THEN 1 ELSE 2 END )
    -- The "1" and "2" are just arbitrary numbers being used to prioritize the rows. Values of 'hello' get "1" so they are ordered before other values.
    LIMIT 1$$

DELIMITER ;

-- Retrieve the questions incorrect answers 
DELIMITER $$
CREATE DEFINER=`root`@`localhost` 
PROCEDURE `GetIncorrectAnswers`(IN `@QuestionID` INT UNSIGNED)
    
    SELECT *
    FROM incorrectanswers
    WHERE incorrectanswers.questionID = `@QuestionID`
    ORDER BY RAND()
    LIMIT 2$$

DELIMITER $$




-- SECURITY MEASURES

--      1: convert SQL queries to *Stored Procerdures* (functions)
--      2: call functions using *Prepared Statements*
--      3: using mysqli_real_escape_string() to remove dangerous chartectors  

