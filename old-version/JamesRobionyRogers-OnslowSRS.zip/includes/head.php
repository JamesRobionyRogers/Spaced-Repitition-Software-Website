<!-- Includes: HTML Page - Head  -->

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1" />

<meta name="description" content=" ... ">
<link rel="icon" href="./imgs/tab-icon.svg">

<!-- Form Validation (Must be loaded in header) -->
<script type="text/javascript" src="js/validate-form.js"></script>

<!-- My CSS Style Sheet -->
<link rel="stylesheet" href="./css/styles.css">

<!-- Imported CSS Styles -->
<link rel="stylesheet" href="css/hamburgers.css">
<link rel="stylesheet" href="sweetalert2.min.css">

<!-- Slick Carousel Javascript Library -->
<!-- Add the slick-theme.css if you want default styling -->
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css"/>

<script src="https://kit.fontawesome.com/dd452af169.js" crossorigin="anonymous"></script>       <!-- Template Line -->


