<div class="quiz-textbox">

    <div class="box-container">

        <form class='question-text-form' name="question" onsubmit="" method="post">
            <label for="answer">Answer</label>
            <input type="text" id="answer" name="userAnswer" placeholder="Your answer..">
        </form>

    </div>


</div>