<?php 

    session_start();

    if( isset($_SESSION['questions']) ) {
        $questions = $_SESSION['questions']; 
    }

    // Setting all vairables  
	if( isset($_GET['id']) ) {
		$quizID = $_GET['id'];
	} else { $quizID = 1; }

    if ( isset($_POST['score']) ) {
        $score = $_POST['score']; 
    } else { $score = 0; }

    if ( isset($_POST['questionNum']) ) {
        $questionNum = $_POST['questionNum']; 
        $questionNum += 1;     
    } else { $questionNum = 0; }


    function getLessonName($dbc, $quizID) {
        // Retrieveing the lesson Name for Heading 
        $getLessonNameQuery = "CALL `GetSubjectName`($quizID)"; 
        $getLessonNameResult = mysqli_query($dbc, $getLessonNameQuery);
        $getLessonNameRecord = mysqli_fetch_assoc($getLessonNameResult);
        $lessonName = $getLessonNameRecord['subjectName'];

        return $lessonName;
    }

    function getQuestions($quizID) {
        $dbc = mysqli_connect("localhost", "root", 'admin', "srs");   

        // Retrieving the qustions 
        $getTenQuestionsQuery = "CALL `GetTenQuestions`($quizID)"; 
        $getTenQuestionsResult = mysqli_query($dbc, $getTenQuestionsQuery);
        // $getTenQuestionsRecord = mysqli_fetch_assoc($getTenQuestionsResult);
          
        foreach($getTenQuestionsResult as $q) {
            $questions[] = $q['questionText']; 
            echo $q['questionID'] . " - " . $q['questionText'] . "<br>";
        }
        return $questions; 
    }

    function checkQuestionType($question) {
        $dbc = mysqli_connect("localhost", "root", 'admin', "srs");
        
        // Retrieving the qustions 
        $checkTypeQuery = 'CALL `CheckQuestionType`("' . $question . '")';
        $checkTypeResult = mysqli_query($dbc, $checkTypeQuery);
        $questionType = mysqli_fetch_assoc($checkTypeResult);
        
        return $questionType; 
    }

    function GetQuestionID($questionText) {
        $dbc = mysqli_connect("localhost", "root", 'admin', "srs");  

        $getQuestionIDQuery = 'CALL `GetQuestionID`("' . $questionText . '")'; 
        $getQuestionIDResult = mysqli_query($dbc, $getQuestionIDQuery);
        $questionID = mysqli_fetch_assoc($getQuestionIDResult);
        
        return $questionID; 
    }

    function getCorrectAnswer($questionID) {
         $dbc = mysqli_connect("localhost", "root", 'admin', "srs");

        $getCorrectAnswerQuery = "CALL `GetCorrectAnswers`($questionID)";
        $getCorrectAnswerResult = mysqli_query($dbc, $getCorrectAnswerQuery);
        $correctAnswer = mysqli_fetch_assoc($getCorrectAnswerResult); 

        return $correctAnswer['correctAnswer'];
    }

    function getIncorrectAnswer($questionID) {
        $dbc = mysqli_connect("localhost", "root", 'admin', "srs");

        $getIncorrectAnswerQuery = "CALL `GetIncorrectAnswers`($questionID)";
        $getIncorrectAnswerResult = mysqli_query($dbc, $getIncorrectAnswerQuery);
        
        foreach($getIncorrectAnswerResult as $i) {
            $incorrectAnswers[] = $i['incorrectAnswer']; 
        }   

        return $incorrectAnswers; 

    }

    function getAnswers($questionID) {
        $correctAnswer = getCorrectAnswer($questionID); 
        $incorrectAnswers = getIncorrectAnswer($questionID); 
        
        try {
            foreach($incorrectAnswers as $i) { 
                $answerPool[] = $i; 
            }
        } catch(Exception $e){}
        
        $answerPool[] = $correctAnswer; 

        shuffle($answerPool);

        return $answerPool; 
    }

	function checkAnswer($question, $userAnswer) {
        // $userAnswer = $_POST['userAnswer'];
        $qID = GetQuestionID($question);
        $answer = getCorrectAnswer($qID['questionID']);

        if ($userAnswer == $answer) {
            echo "<script> answerPopup(true) </script>"; 
        } else {
            echo "<script> answerPopup(false) </script>";
        }
    }

	
 
	
    function loadQuiz($dbc, $quizID) {

        // Check if the user has started the quiz. 
            // If asked isset then quiz in progress
        if ( isset($_POST['asked']) ) {
            // $score = $_POST['score']; 

            // Load the next question
            // loadNextQuestion(); 

        } else { 
            // Other wise,  start a new quiz: 
            // $questions = getQuestions($quizID);     // retrieving the question pool 
            // $currentQuestion = $questions[0];       // setting first question from pool 

            // loadNextQuestion();


        }
    } 

    function loadNextQuestion($questions, $x, $score) {
        
        switch (count($questions) == 0) {
        // if there are no more question, then display the results page 
        case true:
            // createResultsHTML($score, $numberAsked);
            break;
        // Other wise 
        default:
            foreach ($questions as $question) {
                echo $question['question'] . ' • ';
            }

            createQuestionHTML($questions, $numberAsked, $score);
            break;
        }
    }




    // Running the file
    $lessonName = getLessonName($dbc, $quizID);        // Setting the lesson name 
    
    try {
        echo "checking answer"; 
        checkAnswer($currentQuestion, $_POST['userAnswer']);
    } catch (Exception $e) {
        ;
    }
    

    // LoadQuiz function: 

    // Check if the user has started the quiz. 
        // If asked isset then quiz in progress
    if ( isset($_POST['questionNum']) ) {
        // $numberAsked = $_POST['asked'];
        // $score = $_POST['score']; 
        echo (count($questions) - 1);
        if ($questionNum == (count($questions) - 1)) {
            // results page 
            echo "<script> alert('end of questions' </script>"; 
        }

        // Load the next question
        $currentQuestion = $questions[$questionNum];       // setting first question from pool 

    } else { 
        // Other wise,  start a new quiz:
        $questions = getQuestions($quizID);                 // retrieving the question pool 
        $currentQuestion = $questions[$questionNum];       // setting first question from pool 

        // loadNextQuestion();


    }

	
    $_SESSION['questions'] = $questions;
?>