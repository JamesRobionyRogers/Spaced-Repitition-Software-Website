<!--  -->


<nav>
    <ul class="nav-links">
        <li><a class="link home-page" href="">Home</a></li>
        <li id="footer-logo-text" ><a class="logo-text home-page" href="">PYTHON IN 11DIT</a></li>
        <li><a class="yellow link" href="#">Tutorials</a></li>
    </ul>
    
    <!-- Site map tutorial pages -->
    <ul class="site-map">
        <li><a class="loops-page" href="">Loops</a></li>
        <li><a class="try-except-page" href="">Try & Except</a></li>
        <li><a class="lists-page" href="">Lists</a></li>
        <li><a class="functions-page" href="">Functions</a></li>
        <li><a class="classes-page" href="">Classes</a></li>
    </ul>
</nav>

<!-- Mobile Back to top Button  -->
<div class="bk2top">
    <a href="#body-wrapper">
        <p class="bk2top-text">Back <span>to</span> Top</p>
        <div class="bk2top-arrows">
            <div class="arrow arrow-first"></div>
            <div class="arrow arrow-second"></div>
            <div class="arrow arrow-third"></div>
        </div>
    </a>
</div>

<!-- Dark mode Toggle Button -->
<div class="drk-mode">
    <i class="fas fa-moon"></i>
</div>