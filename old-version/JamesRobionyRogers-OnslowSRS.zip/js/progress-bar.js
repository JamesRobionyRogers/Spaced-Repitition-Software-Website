
// const progress = document.querySelector('.progress-done');

// progress.style.width = progress.getAttribute('data-done') + '%';
// progress.style.opacity = 1; 

$(document).ready(function () {
    // Setting const used in function 
    const progress = $('.progress-done');
    const progressText = $('p.progress-text');


    // Setting the percentage of questions done 
    questionsLength = $('.js-info .questions-length').text();    // getting length of the questions array
    prcntIncreace = 100 / questionsLength;                      // dividing the length my 100% to get percentege increase 
    questionNum = $('.js-info .question-num').text();

    alert("Questions Length: " + questionsLength); 
    alert("questionNum: " + questionNum);

    increment = prcntIncreace * questionNum;
    increaseValue = prcentIncreace * increment;
    progress.attr('data-done', increaseValue);                  // increasing vairable by percantege each time


    // Retrieveing the progress amount from the element 
    var progressDone = progress.attr('data-done') + "%"; 

    alert("Progress Done: " + progressDone); 
    
    // Setting the width of the progress bar as percentaege 
    progress.css('width', progressDone);
    progress.css('opacity', 1);

    // Setting the percentage text 
    progressText.text(progressDone); 

});

