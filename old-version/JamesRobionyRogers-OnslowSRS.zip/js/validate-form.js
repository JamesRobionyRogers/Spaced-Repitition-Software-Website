function answerPopup() {
    // testing
    Swal.fire({
        icon: 'info',
        title: 'Checking answer Testing',
        text: 'testing '
    })

    // if (true) {
    //     Swal.fire({
    //         position: 'top-end',
    //         icon: 'success',
    //         title: 'Correct',
    //         showConfirmButton: false,
    //         timer: 1500
    //     })
    // } else {
    //     Swal.fire({
    //         position: 'top-end',
    //         icon: 'error',
    //         title: 'Incorrect',
    //         showConfirmButton: false,
    //         timer: 1500
    //     })
    // }

    setTimeout(10000);
}

// Form validation sourced from: https
function validateForm() {

    // Checking if the user has provided an answer
    let userAnswer = document.forms["question"]["userAnswer"].value;
    if (userAnswer == "" || userAnswer.length == 0) {
        // Alert that there is no choise 
        Swal.fire({
            icon: 'error',
            title: 'Oops... No answer selected',
            text: 'Please provide and answer and submit again.'
        })
        return false;        
    }

    // After, check the answer correct or incorrect 
    answerPopup();
    
    return true;
}