
// Page link vairable
var homePage = "index.php";
var resultsPage = "results.php"; 

// Lesson card Illustrations
var lessonCardTop = "./imgs/lesson-card-top.svg";
var enviroSVG = "./imgs/undraw_environment.svg";

// JQuery setting page links
$(".home-page").attr("href", homePage);

// TODO: Once created pages link them (Uncomment)
// $(".results-page").attr("href", resultsPage);



// JQuery setting tutorial card images
// $("img.illustration.card-top").attr("src", lessonCardTop);
$("img.illustration.enviro").attr("src", enviroSVG);
