
$(document).ready(function () {

    let quizCards = $('.quiz-card-wrapper'); 
    let answerSelected = '';

    $('.quiz-card-container').click(function () {
        $('.selected').removeClass('selected');
        $(this).addClass('selected');

        answerSelected = $(this).text();
        $('input.user-answer').attr('value', answerSelected);
        
    })

    $('form').submit(function () {
        let textAnswerLength = $('input#answer').val().length
        let textAnswer = $('input#answer').val()

        if (textAnswerLength > 0) {
            $('input.user-answer').attr('value', textAnswer);
        }


    });

});